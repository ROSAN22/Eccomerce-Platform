package com.example.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.model.Payment;
import com.example.repo.PaymentRepo;
import com.example.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepo paymentRepo;

    @Override
    public void updatePayment(Payment payment) {
        paymentRepo.save(payment);
    }
}