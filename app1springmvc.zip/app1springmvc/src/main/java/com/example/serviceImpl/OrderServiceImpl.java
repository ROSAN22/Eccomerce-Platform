package com.example.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.model.Order;
import com.example.model.Payment;
import com.example.model.User;
import com.example.repo.OrderRepo;
import com.example.repo.PaymentRepo;
import com.example.service.OrderService;
import com.example.enumerate.OrderStatus;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private PaymentRepo paymentRepo;

    @Override
    public Order createOrder(User user, double totalAmount) {
        Order order = new Order();
        order.setUser(user);
        order.setTotalAmount(totalAmount);
        order.setOrderDate(new Date());
        order.setOrderStatus(OrderStatus.PENDING);

        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(totalAmount);
        payment.setPaymentDate(new Date());
        payment.setPaymentMethod("Not Specified");

        order.setPayment(payment);

        orderRepo.save(order);
        paymentRepo.save(payment);

        return order;
    }

    @Override
    public Optional<Order> getOrderById(Long orderId) {
        return orderRepo.findById(orderId);
    }
    @Override
    public void updateOrder(Order order) {
        orderRepo.save(order);
    }

	@Override
	public void saveOrder(Order order) {
		orderRepo.save(order);
	}

	@Override
	public void savePayment(Payment payment) {
		paymentRepo.save(payment);
	}
	@Override
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }
	@Override
    public List<Order> getOrdersByUser(User user) {
        return orderRepo.findByUser(user);
    }
}