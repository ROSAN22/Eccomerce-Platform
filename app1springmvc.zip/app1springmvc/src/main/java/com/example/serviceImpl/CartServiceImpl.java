package com.example.serviceImpl;
 
import java.util.List;

import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
 
import com.example.model.Cart;

import com.example.model.Product;

import com.example.model.User;

import com.example.repo.CartRepo;

import com.example.repo.ProductRepo;

import com.example.service.CartService;
 
import jakarta.transaction.Transactional;
 
@Service

public class CartServiceImpl implements CartService {

	@Autowired

	private CartRepo cartRepo;

	@Autowired

	private ProductRepo productRepo;
 
	@Override

	@Transactional

	public Cart addProductToCart(Cart cart) {

		return cartRepo.save(cart);

	}
 
	@Override

	@Transactional

	public Optional<Product> findProductById(Long product_id) {

		return productRepo.findById(product_id);

	}
 
	@Override

	@Transactional

    public List<Cart> getCartItemsByUser(User user) {

        return cartRepo.findByUser(user);

    }
 
	@Override

	@Transactional

	public void updateCart(Cart existingCartItem) {

		cartRepo.save(existingCartItem);
 
		

	}
 
	@Override

	@Transactional

	public void removeProductFromCart(User persistentUser, Long product_id) {

        List<Cart> cartItems = cartRepo.findByUser(persistentUser);

        Cart cartItem = cartItems.stream()

                                 .filter(item -> item.getProduct().getProduct_id().equals(product_id))

                                 .findFirst()

                                 .orElse(null);

        if (cartItem != null) {

            cartRepo.delete(cartItem);

        }

    }
 
	@Override

	@Transactional

    public void updateProductQuantityInCart(User user, Long product_id, int quantity) {

        Cart cartItem = cartRepo.findByUserAndProductId(user, product_id);

        if (cartItem != null) {

            cartItem.setQuantity(quantity);

            cartRepo.save(cartItem);

        }

    }
 
 
	@Override

	@Transactional

    public void clearCart(User user) {

        cartRepo.deleteByUser(user);

    }
 
	@Override

    @Transactional

    public void decreaseStockQuantity(Product product, int quantity) {

        product.setStockQuantity(product.getStockQuantity() - quantity);

        productRepo.save(product);

    }
 
 
}

 