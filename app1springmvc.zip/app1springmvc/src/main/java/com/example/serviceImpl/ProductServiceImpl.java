package com.example.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Cart;
import com.example.model.Category;
import com.example.model.Product;
import com.example.repo.CartRepo;
import com.example.repo.ProductRepo;
import com.example.service.ProductService;

import jakarta.transaction.Transactional;
@Service
public class ProductServiceImpl implements ProductService  {
	
	@Autowired
	private ProductRepo productRepo;
	
	@Autowired
	private CartRepo cartRepo;

	@Override
	public Product addProduct(Product productData) {
		return productRepo.save(productData);
	}

	@Override
	public List<Product> getAllProducts() {
		return productRepo.findAll();
	}

	@Override
	public Product getProductById(Long productId) {
        Optional<Product> product = productRepo.findById(productId);
        return product.orElse(null);
	}

	@Override
	public Product updateProduct(Product productData) {
		return productRepo.save(productData);
	}

	@Override
	public Product updateProductDatas(Long product_id, String product_name, String description, double product_price,int stockQuantity, Category category , String imageData	) {
		Optional<Product> findProductById = productRepo.findById(product_id);
		System.out.println("product id found");
		if(findProductById.isPresent()) {
			Product product = findProductById.get();
			product.setProduct_name(product_name);
			product.setDescription(description);
			product.setProduct_price(product_price);
			product.setStockQuantity(stockQuantity);
			product.setCategory(category);
			product.setImageData(imageData);
			return productRepo.save(product);
		}else {
			return null;
		}
	}
	

	@Override
	public void deleteById(Long product_id) {
		productRepo.deleteById(product_id);
		
	}

	@Override
	public void deleteProduct(long product_id) {
		// TODO Auto-generated method stub
		productRepo.deleteById(product_id);
	}

	@Override
	public List<Product> searchProductsByName(String productName) {
	    return productRepo.searchByProductName(productName);
	}

	@Override
	@Transactional
	public void deleteProductById(Long product_id) {
	    Product product = productRepo.findById(product_id).orElseThrow(() -> new RuntimeException("Product not found"));
	    System.out.println("Deleting order items for product: " + product_id);
	    
	    System.out.println("Deleting cart items for product: " + product_id);
	    cartRepo.deleteByProductId(product_id);
	    
	    System.out.println("Deleting product: " + product_id);
	    try {
	        productRepo.deleteById(product_id);
	    } catch (Exception e) {
	        System.err.println("Error deleting product: " + e.getMessage());
	    }
	    boolean exists = productRepo.existsById(product_id);
	    if (exists) {
	        System.out.println("Product not deleted: " + product_id);
	    } else {
	        System.out.println("Product successfully deleted: " + product_id);
	    }
 
	}
 

	
	

	

//	@Override
//	public List<Product> searchProductsByName(String searchQuery) {
//        return productRepo.findByProductNameContainingIgnoreCase(searchQuery);
//	}

}
