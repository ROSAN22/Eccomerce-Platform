package com.example.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.enumerate.UserRole;
import com.example.model.User;
import com.example.repo.UserRepo;
import com.example.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepo userRepo;
	
    @Autowired
    private PasswordEncoder passwordEncoder;

    
	
	//save register details

	@Override
	public void saveUser(User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);

		userRepo.save(user);
		
	}

    //find whether the username is exists or not for login	
	
	@Override
	public User authenticate(String username, String password) {
		Optional<User> finduserExists = userRepo.findByUsername(username);
		if (finduserExists.isPresent()) {
			User user = finduserExists.get();
			if (passwordEncoder.matches(password, user.getPassword())) {
				return user;
			}
		}
		return null;
	}

	@Override
	public List<User> getAllUsers() {
	   return userRepo.findAll();
	}

	@Override
	public User searchUserByid(long userid) {
		return userRepo.findById(userid).orElse(null);
	}

	@Override
	public User getUserById(Long userid) {
		Optional<User>userdata = userRepo.findById(userid);
		return userdata.orElse(null);
	}

	@Override
	public User updateUserDetails(long userid, String username, String email,String password) {
		Optional<User> findUserByid = userRepo.findById(userid);
		if(findUserByid.isPresent()) {
			User user = findUserByid.get();
			user.setUsername(username);
			user.setEmail(email);
	        String encodedPassword = passwordEncoder.encode(password);
	        user.setPassword(encodedPassword);

			return userRepo.save(user);
		}
		return null;
	}

	@Override
	public void deleteUserById(Long userid) {
		userRepo.deleteById(userid);
		
	}

	@Override
	public User addUser(User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);

		return userRepo.save(user);
	}

//	@Override
//	public User updateUserData(Long userid, String username,String email, String password, UserRole userrole) {
//		Optional<User>findUserByid = userRepo.findById(userid);
//		if(findUserByid.isPresent()) {
//		User user = new User();
//		user.setUsername(username);
//		user.setEmail(email);
//		user.setPassword(password);
//		user.setUserrole(userrole);
//		return userRepo.save(user);
//		}
//		return null;
//	}

	@Override
	public User updateUserData(User user) {
	    Optional<User> existingUserOptional = userRepo.findById(user.getUserid());
	    if (existingUserOptional.isPresent()) {
	        User existingUser = existingUserOptional.get();
	        existingUser.setUsername(user.getUsername());
	        existingUser.setEmail(user.getEmail());
	        existingUser.setPassword(user.getPassword());
	        existingUser.setUserrole(user.getUserrole());
	        return userRepo.save(existingUser);
	    } else {
	        return null;
	    }
	}

	@Override
	public Optional<User> findById(long userid) {
		return userRepo.findById(userid);
	}

}
