package com.example.dto;
 
import com.example.enumerate.UserRole;
 
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
public class UserDTO {
 
    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@NotEmpty(message="Username is blank")
    @Size(min=3, max=20, message="Username must be between 3 and 20 characters")
    @Pattern(regexp="^[a-zA-Z0-9]{8,}$", message="Username should contain letters and numbers")
    private String username;
 
    @NotEmpty(message="Password is blank")
    @Size(min=8, message="Password must be at least 8 characters long")
    @Pattern(regexp="^(?=.*\\d)(?=.*[A-Za-z])(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", 
             message="Password must be at least 8 characters long, contain at least one digit, one letter, and one special character")
    private String password;
 
    @Email(message="Email should be valid")
    @NotEmpty(message="Email is blank")
    private String email;
 
    private UserRole userrole;
 
    private String errorMessage;

	public UserRole getUserrole() {
		return userrole;
	}

	public void setUserrole(UserRole userrole) {
		this.userrole = userrole;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	} 
    }