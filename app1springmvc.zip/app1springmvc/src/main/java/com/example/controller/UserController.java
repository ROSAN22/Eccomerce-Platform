package com.example.controller;
import java.beans.PropertyEditorSupport;
import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dto.UserDTO;
import com.example.enumerate.UserRole;
import com.example.model.User;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	private String index() {
		return "index";
	}
	
	@GetMapping("/getAlluser")
	public String getAllUsers(ModelMap map,HttpSession session) {
		if((User)session.getAttribute("loggedInUser")!=null) {
			return "redirect:/user/login";
		}
		List<User>  userList = userService.getAllUsers();
		map.addAttribute("user",userList );
		return "userdata";
	}
	
	@GetMapping("/register")
	public String getRegisterPage(ModelMap map) {
		map.addAttribute("user" , new UserDTO());//add an empty user object 
		return "registerForm";  // getmapping fetches the form and maps the form data to the user attributes
	}
    @PostMapping("/register")
    public String postRegisterDetails(
            @ModelAttribute("user") @Valid UserDTO userdto,
            BindingResult result,
            ModelMap map) {
        if (result.hasErrors()) {
            return "registerForm"; // Return the form view with error messages
        }
 
        // Map UserDTO to User entity
        User user = new User();
        user.setUsername(userdto.getUsername());
        user.setPassword(userdto.getPassword());
        user.setEmail(userdto.getEmail());
        user.setUserrole(userdto.getUserrole());
 
        userService.saveUser(user);
        return "redirect:/user/login";
	}
    @GetMapping("/login")
    public String getLoginPage(HttpSession session, ModelMap map) {
        User userfound = (User) session.getAttribute("loggedInUser");
        if (userfound != null) {
            if (userfound.getUserrole() == UserRole.ADMIN) {
                return "redirect:/admin/home";
            } else {
                return "redirect:/customer/home";
            }
        }
        map.addAttribute("userlogin", new User());
        return "loginForm";
    }

    @PostMapping("/login")
    public String postLoginDetails(
            @ModelAttribute("userlogin") @Valid User user,
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            HttpSession session,
            ModelMap map) {
        User userfound = userService.authenticate(username, password);
        if (userfound != null) {
            session.setAttribute("loggedInUser", userfound);
            return userfound.getUserrole() == UserRole.ADMIN ? "redirect:/admin/home" : "redirect:/customer/home";
        } else {
            map.addAttribute("errorMessage", "Invalid username or password.");
            return "loginForm";
        }
    }

	
//	update user details 
	
	@GetMapping("/update")
	public String showUpdateForm(@RequestParam("userid") long userid, ModelMap map) {
	    User user = userService.getUserById(userid);
	    map.addAttribute("user", user);
	    return "updateUser";
	}
 
	@PostMapping("/update")
	public String updateUserData(
	        @RequestParam("userid") long userid,
	        @RequestParam("username") String username,
	        @RequestParam("email") String email,
	        @RequestParam("password") String password,
	        ModelMap map) {
	    System.out.println("update");
	    User updatedUser = userService.updateUserDetails(userid, username, email, password);
	    if (updatedUser != null) {
	        System.out.println("update " + updatedUser.toString());
	        map.addAttribute("user", updatedUser);
	        return "redirect:/user/listUser";
	    } else {
	        return "error";
	    }
	}
	
	@GetMapping("/delete")
	public String showdeleteUserForm(ModelMap map
			) {
		map.addAttribute("user",new User());
		return "deleteUserForm";
	}
	
	@PostMapping("/delete")
	public String deleteUser(@ModelAttribute("userid") Long userid , ModelMap map) {
		userService.deleteUserById(userid);
		return "redirect:/user/listUser";
	}	
//	list all user
	
	@GetMapping("/listUser")
	public String listAllUserData(ModelMap map) {
		List<User> listUser = userService.getAllUsers();
		map.addAttribute("user",listUser);
		return "listUserDetails";
	}
	
//	add user
	@GetMapping("/add")
	public String showaddUserForm(ModelMap map) {
		map.addAttribute("user",new User());
		return "addUserForm";
	}
	@PostMapping("/add")
	public String addUserData(@ModelAttribute("user") User user ,ModelMap map) {
		User userData = userService.addUser(user);
		map.addAttribute("user",userData);
		return "redirect:/user/listUser";
	}
	
//	update user
	
}
