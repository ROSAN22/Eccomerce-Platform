package com.example.controller;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
 
import com.example.enumerate.UserRole;
import com.example.model.Cart;
import com.example.model.User;
import com.example.service.CartService;

import jakarta.servlet.http.HttpSession;
 
@Controller
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CartService cartService;
	@GetMapping("/home")
	public String showCustomerHome(HttpSession session) {
		User userfound = (User) session.getAttribute("loggedInUser");
		if(userfound != null && userfound.getUserrole() == UserRole.CUSTOMER) {
		return "customerdashboard";
		}else {
			return "redirect:/user/login";
		}
	}
	@GetMapping("/listProduct")
	public String listProducts() {
		return "custProduct";
	}
	@GetMapping("/payment")
	public String payment() {
		return "payment";
	}
	@GetMapping("/cart")
	public String viewCart(ModelMap model, HttpSession session) {
	    User loggedInUser = (User) session.getAttribute("loggedInUser");
	    if (loggedInUser == null) {
	        return "redirect:/user/login";
	    }
 
	    List<Cart> cartItems = cartService.getCartItemsByUser(loggedInUser);
	    System.out.println(cartItems);
	    cartItems.forEach(item -> System.out.println("CartItem: " + item.getProduct().getProduct_name() + ", Quantity: " + item.getQuantity()));
 
	    model.addAttribute("cartItems", cartItems);
 
	    double totalPrice = cartItems.stream()
	                                 .mapToDouble(item -> item.getProduct().getProduct_price() * item.getQuantity())
	                                 .sum();
	    model.addAttribute("totalPrice", totalPrice);
 
	    return "addtocart";
	}
 
 
}