package com.example.controller;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
 
import com.example.model.Cart;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.UserService;
 
import jakarta.servlet.http.HttpSession;
 
@Controller
@RequestMapping("/cart")
public class CartController {
	@Autowired
	private CartService cartService;
    @Autowired
    private UserService userService;
    @PostMapping("/add")
    public String addProductToCart(@RequestParam Long product_id, @RequestParam int quantity, @AuthenticationPrincipal User user, HttpSession session, ModelMap model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            System.err.println("User is not authenticated");
            return "redirect:/user/login";
        }
 
        Optional<Product> optionalProduct = cartService.findProductById(product_id);
        if (!optionalProduct.isPresent()) {
            System.err.println("Product not found: " + product_id);
            return "redirect:/error?message=Product not found";
        }
        Product product = optionalProduct.get();
 
        List<Cart> cartItems = cartService.getCartItemsByUser(loggedInUser);
        Cart existingCartItem = cartItems.stream()
                                         .filter(item -> item.getProduct().getProduct_id().equals(product_id))
                                         .findFirst()
                                         .orElse(null);
 
        int totalQuantity = quantity;
        if (existingCartItem != null) {
            totalQuantity += existingCartItem.getQuantity();
        }
 
        if (product.getStockQuantity() < totalQuantity) {
            model.addAttribute("errorMessage", "The product is out of stock. We will let you know once the stock is available.");
            return "redirect:/customer/cart";
        }
 
        if (existingCartItem != null) {
            existingCartItem.setQuantity(totalQuantity);
            cartService.updateCart(existingCartItem);
        } else {
            Cart cart = new Cart();
            cart.setUser(loggedInUser);
            cart.setProduct(product);
            cart.setQuantity(quantity);
            cartService.addProductToCart(cart);
        }
 
        return "redirect:/customer/cart";
    }
    @PostMapping("/remove")
    public String removeProductFromCart(@RequestParam Long product_id, @AuthenticationPrincipal User user, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            System.err.println("User is not authenticated");
            return "redirect:/user/login";
        }
 
        // Fetch the user from the database
        Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
        if (!optionalUser.isPresent()) {
            System.err.println("User not found: " + loggedInUser.getUserid());
            return "redirect:/error?message=User not found";
        }
        User persistentUser = optionalUser.get();
 
        // Fetch the product from the database
        Optional<Product> optionalProduct = cartService.findProductById(product_id);
        if (!optionalProduct.isPresent()) {
            System.err.println("Product not found: " + product_id);
            return "redirect:/error?message=Product not found";
        }
 
        // Remove the product from the cart
        cartService.removeProductFromCart(persistentUser, product_id);
 
        return "redirect:/customer/cart";
    }
    @GetMapping("/view")
    public String viewCartItems(@AuthenticationPrincipal User user, HttpSession session, ModelMap model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            System.err.println("User is not authenticated");
            return "redirect:/user/login";
        }
 
        // Fetch the user from the database
        Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
        if (!optionalUser.isPresent()) {
            System.err.println("User not found: " + loggedInUser.getUserid());
            return "redirect:/error?message=User not found";
        }
        User persistentUser = optionalUser.get();
 
        // Get the cart items for the user
        List<Cart> cartItems = cartService.getCartItemsByUser(persistentUser);
        model.addAttribute("cartItems", cartItems);
 
        return "cart/view";
    }
 
//    @PostMapping("/update")
//    public String updateProductQuantityInCart(@RequestParam Long product_id, @RequestParam int quantity, @AuthenticationPrincipal User user, HttpSession session) {
//        User loggedInUser = (User) session.getAttribute("loggedInUser");
//        if (loggedInUser == null) {
//            return "redirect:/user/login";
//        }
//
//        cartService.updateProductQuantityInCart(loggedInUser, product_id, quantity);
//        return "redirect:/customer/cart";
//    }
    @PostMapping("/update")
    public String updateCart(@RequestParam Long product_id, @RequestParam int quantity, @AuthenticationPrincipal User user, HttpSession session, ModelMap model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            System.err.println("User is not authenticated");
            return "redirect:/user/login";
        }
 
        Optional<Product> optionalProduct = cartService.findProductById(product_id);
        if (!optionalProduct.isPresent()) {
            System.err.println("Product not found: " + product_id);
            return "redirect:/error?message=Product not found";
        }
        Product product = optionalProduct.get();
 
        if (product.getStockQuantity() < quantity) {
            model.addAttribute("errorMessage", "The product is out of stock. We will let you know once the stock is available.");
            return "redirect:/customer/cart";
        }
 
        // Update the cart item
        cartService.updateProductQuantityInCart(loggedInUser, product_id, quantity);
 
        return "redirect:/customer/cart";
    }
 
 
    
}