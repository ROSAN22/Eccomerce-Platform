package com.example.controller;

import java.util.Optional;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.enumerate.OrderStatus;
import com.example.model.Cart;
import com.example.model.Order;
import com.example.model.Payment;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.OrderService;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/order")
public class OrderController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private CartService cartService;
    
    @Autowired
    private OrderService orderService;
    
    @GetMapping("/checkout")
    public String showCheckOutPage(@AuthenticationPrincipal User user, ModelMap model, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            System.err.println("User is not found");
            return "redirect:/user/login";
        }
        Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
        if (!optionalUser.isPresent()) {
            System.err.println("User not found: " + loggedInUser.getUserid());
            return "redirect:/error?message=User not found";
        }
        User persistentUser = optionalUser.get();
        List<Cart> cartItems = cartService.getCartItemsByUser(persistentUser);
        if (cartItems.isEmpty()) {
            System.err.println("Cart is empty for user: " + loggedInUser.getUserid());
            return "redirect:/error?message=Cart is empty";
        }
        double totalAmount = cartItems.stream()
                                      .mapToDouble(item -> item.getProduct().getProduct_price() * item.getQuantity())
                                      .sum();
        Order order = new Order();
        order.setUser(persistentUser);
        order.setTotalAmount(totalAmount);
        order.setOrderDate(new Date());
        order.setOrderStatus(OrderStatus.PENDING);
        
        model.addAttribute("order", order);
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalAmount", totalAmount);
        
        return "checkout";
    }
    
    @PostMapping("/placeOrder")
    public String placeOrder(@AuthenticationPrincipal User user, HttpSession session, @RequestParam("paymentMethod") String paymentMethod) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            System.err.print("User is not found");
            return "redirect:/user/login";
        }
        Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
        if (!optionalUser.isPresent()) {
            System.err.println("User not found: " + loggedInUser.getUserid());
            return "redirect:/error?message=User not found";
        }
        User persistentUser = optionalUser.get();
        List<Cart> cartItems = cartService.getCartItemsByUser(persistentUser);
        if (cartItems.isEmpty()) {
            System.err.println("Cart is empty for user: " + loggedInUser.getUserid());
            return "redirect:/error?message=Cart is empty";
        }
        
        double totalAmount = cartItems.stream()
                .mapToDouble(item -> item.getProduct().getProduct_price() * item.getQuantity())
                .sum();
        
        Order order = new Order();
        order.setUser(persistentUser);
        order.setTotalAmount(totalAmount);
        order.setOrderDate(new Date());
        order.setOrderStatus(OrderStatus.PENDING);
        
        // Save the order first
        orderService.saveOrder(order);
        
        // Now create OrderItems
        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(totalAmount);
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentDate(new Date());
        
        orderService.savePayment(payment);
        
        // Update the order with the payment date
        order.setPaymentDate(payment.getPaymentDate());
        orderService.saveOrder(order);
        
        // Decrease the stock quantity for each product in the cart
        for (Cart cartItem : cartItems) {
            Product product = cartItem.getProduct();
            cartService.decreaseStockQuantity(product, cartItem.getQuantity());
        }
        cartService.clearCart(persistentUser);
        session.setAttribute("cartCount", -1);
        
        System.out.println("Cart count after clearing: " + session.getAttribute("totalItems"));
        return "redirect:/order/confirmation";
    }
    
    @GetMapping("/confirmation")
    public String orderConfirmation() {
        return "paymentSuccess";
    }
    @GetMapping("/myOrders")
    public String viewMyOrders(@AuthenticationPrincipal User user, HttpSession session, ModelMap model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/user/login";
        }
        List<Order> orders = orderService.getOrdersByUser(loggedInUser);
        model.addAttribute("orders", orders);
        return "myOrders";
    }
}
