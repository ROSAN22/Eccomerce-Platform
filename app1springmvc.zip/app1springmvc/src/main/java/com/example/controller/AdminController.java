package com.example.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.enumerate.OrderStatus;
import com.example.enumerate.UserRole;
import com.example.model.Order;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.OrderService;
import com.example.service.ProductService;
import com.example.serviceImpl.ProductServiceImpl;

import ch.qos.logback.core.joran.spi.HttpUtil.RequestMethod;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private OrderService orderService;
	
	@Autowired 
	private ProductService productService;
	
	@GetMapping("/home")
	public String showAdminHome(HttpSession session) {
	    User userfound = (User) session.getAttribute("loggedInUser");
	    if (userfound != null && userfound.getUserrole() == UserRole.ADMIN) {
	        return "admindashboard";
	    } else {
	        return "redirect:/user/login";
	    }
	}	@GetMapping("/logout")
	public String logout(HttpServletRequest request,HttpSession session) {
//		session.invalidate();
	    request.getSession().invalidate();
	    return "redirect:/user/login";
	}
	@GetMapping("/product")
	public String product() {
		return "product";
	}
	@RequestMapping("/product/delete/{product_id}")
	public String deleteProduct(@PathVariable("product_id") long product_id) {
	    productService.deleteProduct(product_id);
	    return "redirect:/product";
	}
	@GetMapping("/user")
	public String user() {
		return "user";
	}
	
	@GetMapping("/category")
	public String category() {
		return "category";
	}
	@GetMapping("/cart")
	public String cart() {
		return "cart";
	}
	@GetMapping("/orders")
    public String viewOrders(ModelMap model) {
        model.addAttribute("orders", orderService.getAllOrders());
        return "adminOrders";
    }

    @PostMapping("/updateOrderStatus")
    public String updateOrderStatus(@RequestParam Long orderId, @RequestParam OrderStatus orderStatus) {
        Optional<Order> optionalOrder = orderService.getOrderById(orderId);
        if (optionalOrder.isPresent()) {
            Order order = optionalOrder.get();
            order.setOrderStatus(orderStatus);
            orderService.updateOrder(order);
        }
        return "redirect:/admin/orders";
    }
}
