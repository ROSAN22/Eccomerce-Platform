package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.enumerate.UserRole;
import com.example.model.Category;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CategoryService;
import com.example.service.ProductService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import java.util.*;
@Controller
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping("/addProduct")
	public String showaddProductForm(ModelMap map) {
		map.addAttribute("product",new Product());
		List<Category> categories = categoryService.getAllCategories();
        map.addAttribute("categories", categories);

		return "addProductForm";
	}
	
	@PostMapping("/addProduct")
	public String addProduct(
			@ModelAttribute("product") @Valid Product productData,
			ModelMap model
			) {
		try {
			Product addedProduct = productService.addProduct(productData);
			System.out.println(productData);
			model.addAttribute("product",addedProduct);
			return "redirect:/product/listProducts";
		}catch(Exception e) {
			return "error";
		}
	}
	
//	list all products
    @GetMapping("/listProducts")
    public String listProducts(ModelMap model) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "productList";
    }
    
    @GetMapping("/listAllProduct")
    public String listProduct(ModelMap model , HttpSession session) {
		User userfound = (User) session.getAttribute("loggedInUser");
		if(userfound != null && userfound.getUserrole() == UserRole.CUSTOMER) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "custProduct";
		}else {
			return "redirect:/user/login";
		}
    }
    

//	update product
    
    
    @GetMapping("/updateproduct")
    public String showUpdateProductForm(@RequestParam("product_id") long product_id,ModelMap model) {
    	Product product = productService.getProductById(product_id);
    	model.addAttribute("product",product);
    	System.out.println("get product");
    	List<Category> categories = categoryService.getAllCategories();
    	System.out.println("Categories");
     categories.forEach(a->System.out.println(a.getCategory_id()+"\t"+a.getCategory_name()));
        model.addAttribute("categories", categories);
        System.out.println("get category");
    	return "updateProductForm";
    }
 
    @PostMapping("/updateproduct")
    public String updateProductData(
            @ModelAttribute("product") Product product,
            @RequestParam("category") Long categoryId,
            ModelMap map) {
        System.out.println("update product");
        Category category = categoryService.getCategoryById(categoryId);
        if (category == null) {
            System.out.println("no values");
        }
        System.out.println("id " + product.getProduct_id() + " name " + product.getProduct_name() + " price " + product.getProduct_price() + " category " + category);
        Product updatedProduct = productService.updateProductDatas(product.getProduct_id(), product.getProduct_name(), product.getDescription(), product.getProduct_price(), product.getStockQuantity(), category, product.getImageData());
        System.out.println("user 11 found " + updatedProduct);
 
        if (updatedProduct != null) {
            map.addAttribute("product", updatedProduct);
            System.out.println("user found");
            return "redirect:/product/listProducts";
        } else {
            return "error";
        }
    }
    
    
    
    
    @GetMapping("/search")
    public String searchProducts(@RequestParam("productName") String productName, ModelMap model) {
        List<Product> products = productService.searchProductsByName(productName);
        model.addAttribute("products", products);
        return "custProduct";
    }
//    delete product 
    
    @GetMapping("/deleteProduct")
    public String showdeleteProductForm(ModelMap map) {
    	map.addAttribute("product",new Product());
    	return "deleteProductForm";
    }
    @PostMapping("/deleteProduct")
    public String deleteProductData(
    		@ModelAttribute("product_id") Long product_id ,
    		ModelMap map) {
    	productService.deleteProductById(product_id);
    	return "redirect:/product/listProducts";
    }
}
