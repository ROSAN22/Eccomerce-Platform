package com.example.controller;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.enumerate.OrderStatus;
import com.example.model.Order;
import com.example.model.Payment;
import com.example.model.User;
import com.example.service.OrderService;
import com.example.service.PaymentService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/pay")
    public String showPaymentPage(@RequestParam Long orderId, ModelMap model) {
        Optional<Order> order = orderService.getOrderById(orderId);
        if (order == null) {
            return "redirect:/error?message=Order not found";
        }
        model.addAttribute("order", order);
        return "payment";
    }

    @PostMapping("/process")
    public String processPayment(@RequestParam Long orderId, @RequestParam String paymentMethod, @AuthenticationPrincipal User user, HttpSession session, ModelMap model) {
        Optional<Order> optionalOrder = orderService.getOrderById(orderId);
        if (!optionalOrder.isPresent()) {
            return "redirect:/error?message=Order not found";
        }
        Order order = optionalOrder.get();

        
        Payment payment = order.getPayment();
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentDate(new Date());
        paymentService.updatePayment(payment);

        order.setOrderStatus(OrderStatus.COMPLETED);
        orderService.updateOrder(order);

        model.addAttribute("order", order);
        return "paymentSuccess";
    }
}