package com.example.repo;
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;
 
import com.example.model.Cart;
import com.example.model.Product;
import com.example.model.User;

import jakarta.transaction.Transactional;
 
public interface CartRepo extends JpaRepository<Cart, Long> {
 
	List<Cart> findByUser(User user);
 
	

    @Query("SELECT c FROM Cart c WHERE c.user = :user AND c.product.product_id = :product_id")

    Cart findByUserAndProductId(@Param("user") User user, @Param("product_id") Long product_id);
 
 
	void deleteByUser(User user);



	@Modifying
	@Transactional
	@Query("DELETE FROM Cart c WHERE c.product.id = :productId")
	void deleteByProductId(@Param("productId") Long productId);

 
}

 