package com.example.enumerate;

public enum OrderStatus {
	
	 PENDING,SHIPPED,DELIVERED,CANCELLED, COMPLETED 


}
