package com.example.enumerate;

public enum UserRole {
	CUSTOMER,ADMIN
}
