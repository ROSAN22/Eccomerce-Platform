package com.example.service;

import java.util.List;

import com.example.model.Category;
import com.example.model.Product;

public interface ProductService {

	Product addProduct(Product productData);

	List<Product> getAllProducts();

	Product getProductById(Long productId);

	Product updateProduct(Product productData);

	Product updateProductDatas(Long product_id, String product_name, String description, double product_price,int stockQuantity,Category category,String imageData);

	void deleteById(Long product_id);

	void deleteProduct(long productId);

	List<Product> searchProductsByName(String productName);

	void deleteProductById(Long product_id);

	

	

	


}
