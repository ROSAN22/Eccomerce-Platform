package com.example.service;
import java.util.*;

import com.example.enumerate.UserRole;
import com.example.model.User;

public interface UserService {

	void saveUser(User user);

	User authenticate(String username, String password);

	List<User> getAllUsers();

	User searchUserByid(long userid);

	User getUserById(Long userid);

	User updateUserDetails(long userid, String username, String email , String password);

	void deleteUserById(Long userid);

	User addUser(User user);

	User updateUserData(User user);

	Optional<User> findById(long userid);

}
