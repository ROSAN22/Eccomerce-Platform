package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.model.Order;
import com.example.model.Payment;
import com.example.model.User;

public interface OrderService {
    Order createOrder(User user, double totalAmount);
    Optional<Order> getOrderById(Long orderId);
    void updateOrder(Order order);
	void saveOrder(Order order);
	void savePayment(Payment payment);
	List<Order> getAllOrders();
	List<Order> getOrdersByUser(User user);
}