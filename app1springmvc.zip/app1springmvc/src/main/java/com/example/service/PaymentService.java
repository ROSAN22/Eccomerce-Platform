package com.example.service;

import com.example.model.Payment;

public interface PaymentService {
    void updatePayment(Payment payment);
}