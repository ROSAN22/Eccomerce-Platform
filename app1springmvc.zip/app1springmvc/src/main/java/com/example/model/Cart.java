package com.example.model;

import jakarta.persistence.*;

@Entity
@Table(name="cart")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cartId;

    @ManyToOne
    @JoinColumn(name="userid", referencedColumnName = "userid", nullable=false)
    private User user;

    @ManyToOne
    @JoinColumn(name="orderid", referencedColumnName = "orderid")
    private Order order;

    @ManyToOne
    @JoinColumn(name="product_id", referencedColumnName = "product_id", nullable=false)
    private Product product;
    

    @Column(nullable=false)
    private int quantity;

    // Getters and Setters
    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}