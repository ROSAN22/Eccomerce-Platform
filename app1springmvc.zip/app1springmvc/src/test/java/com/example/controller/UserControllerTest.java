package com.example.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.junit.jupiter.api.extension.ExtendWith;
import com.example.model.User;
import com.example.service.UserService;
import java.util.Arrays;
import java.util.List;
 

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {
 
    @Mock
    private UserService userService;
    @InjectMocks
    UserController userController;
    private MockMvc mockMvc;
    
    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }
 
    @Test
    public void testGetAllUsers() throws Exception {
        User user1 = new User();
        user1.setUserid(1L);
        user1.setUsername("user1");
        user1.setEmail("user1@example.com");
        user1.setPassword("password1");
        User user2 = new User();
        user2.setUserid(2L);
        user2.setUsername("user2");
        user2.setEmail("user2@example.com");
        user2.setPassword("password2");
        List<User> userList = Arrays.asList(user1, user2);
        when(userService.getAllUsers()).thenReturn(userList);
        mockMvc.perform(get("/user/getAlluser"))
                .andExpect(status().isOk())
                .andExpect(view().name("userdata"))
                .andExpect(model().attributeExists("user"))
                .andExpect(model().attribute("user", userList));
        verify(userService, times(1)).getAllUsers();
    }
 
    @Test
    public void testUpdateUser() throws Exception {
        User user = new User();
        user.setUserid(1L);
        user.setUsername("updatedUser");
        user.setEmail("updated@example.com");
        user.setPassword("updatedPassword");
        when(userService.updateUserDetails(anyLong(), anyString(), anyString(), anyString())).thenReturn(user);
        mockMvc.perform(post("/user/update")
                .param("userid", "1")
                .param("username", "updatedUser")
                .param("email", "updated@example.com")
                .param("password", "updatedPassword"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customer/home"));
        verify(userService, times(1)).updateUserDetails(anyLong(), anyString(), anyString(), anyString());

    }
 
    @Test
    public void testDeleteUser() throws Exception {
        mockMvc.perform(post("/user/delete")
                .param("userid", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/user/listUser"));
        verify(userService, times(1)).deleteUserById(1L);
    }
 
    @Test
    public void testAddUser() throws Exception {
        User user = new User();
        user.setUserid(1L);
        user.setUsername("newUser");
        user.setEmail("new@example.com");
        user.setPassword("newPassword");
        when(userService.addUser(any(User.class))).thenReturn(user);
        mockMvc.perform(post("/user/add")
                .flashAttr("user", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/user/listUser"));
        verify(userService, times(1)).addUser(any(User.class));
    }
 
    @Test
    public void testListAllUserData() throws Exception {
        User user1 = new User();
        user1.setUserid(1L);
        user1.setUsername("user1");
        user1.setEmail("user1@example.com");
        user1.setPassword("password1");
        User user2 = new User();
        user2.setUserid(2L);
        user2.setUsername("user2");
		user2.setEmail("user2@example.com");
		user2.setPassword("password2");
		List<User> userList = Arrays.asList(user1, user2);
		when(userService.getAllUsers()).thenReturn(userList);
		mockMvc.perform(get("/user/listUser"))
                .andExpect(status().isOk())
                .andExpect(view().name("listUserDetails"))
                .andExpect(model().attributeExists("user"))
                .andExpect(model().attribute("user", userList));
        verify(userService, times(1)).getAllUsers();
    }

}

 